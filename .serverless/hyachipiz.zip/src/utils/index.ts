import { acceptedProps } from './accepted-props';
export { acceptedProps };
