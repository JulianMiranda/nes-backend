export enum ROLES {
  ADMIN = 'ADMIN',
  CLIENT = 'CLIENT',
}
