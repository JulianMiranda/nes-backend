export const PORT = process.env.PORT || 3000;
export const SECRET_JWT = process.env.SECRET_JWT || 'secret-local-no-prod';
export const AWS_REG = process.env.AWS_REG || 'us-east-1';
